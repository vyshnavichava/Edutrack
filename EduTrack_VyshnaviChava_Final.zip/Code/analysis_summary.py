import pandas as pd
import pyodbc

# Connect to Azure SQL
conn = pyodbc.connect(
    "DRIVER={ODBC Driver 18 for SQL Server};"
    "SERVER=edutracksqlsrv123.database.windows.net;"
    "DATABASE=EduTrackDB;"
    "UID=azureuser;"
    "PWD=Vyshnavi@2005;"
    "Encrypt=yes;"
    "TrustServerCertificate=no;"
    "Connection Timeout=30;"
)
# Load data
df = pd.read_sql("SELECT * FROM student_performance", conn)
# Rename columns for clarity
df.rename(columns={'sex': 'gender', 'g3': 'score'}, inplace=True)
# Average score by gender
print("\n📊 Average Score by Gender:")
print(df.groupby('gender')['score'].mean())
# Distribution of Scores
print("\n📊 Score Distribution:")
print(df['score'].describe())
# High Performers
print("\n🏆 High Performing Students (score ≥ 15):")
print(df[df['score'] >= 15][['gender', 'score']].head())
# Correlation between studytime and score
print("\n📈 Correlation between Study Time and Score:")
print(df[['studytime', 'score']].corr())

# Close connection
conn.close()
