import pandas as pd
from sqlalchemy import create_engine

# ✅ Fixed credentials with URL encoding
username = 'azureuser'
password = 'Vyshnavi%402005'  # '@' is replaced by %40
server = 'edutracksqlsrv123.database.windows.net'
database = 'EduTrackDB'
driver = 'ODBC Driver 18 for SQL Server'

# ✅ Full CSV path (based on your earlier screenshots)
file_path = r'C:\Users\vyshn\EduTrack\data\cleaned\students_cleaned.csv'

# ✅ Read CSV
df = pd.read_csv(file_path)

# ✅ SQLAlchemy connection string
conn_str = (
    f"mssql+pyodbc://{username}:{password}@{server}:1433/{database}"
    f"?driver={driver.replace(' ', '+')}&Encrypt=yes&TrustServerCertificate=no"
)

# ✅ Create engine and upload
engine = create_engine(conn_str)
df.to_sql('student_performance', con=engine, if_exists='append', index=False)

print("✅ Data uploaded successfully!")
