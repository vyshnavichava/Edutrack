import pyodbc
import pandas as pd

# Azure SQL connection
conn = pyodbc.connect(
    "DRIVER={ODBC Driver 18 for SQL Server};"
    "SERVER=edutracksqlsrv123.database.windows.net;"
    "DATABASE=EduTrackDB;"
    "UID=azureuser;"
    "PWD=Vyshnavi@2005;"
    "Encrypt=yes;"
    "TrustServerCertificate=no;"
    "Connection Timeout=30;"
)

# Query uploaded data
query = "SELECT TOP 10 * FROM student_performance"
df = pd.read_sql(query, conn)
print(df)
