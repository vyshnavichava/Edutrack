import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
import pyodbc
import os
# Step 1: Connect to Azure SQL
conn = pyodbc.connect(
    "DRIVER={ODBC Driver 18 for SQL Server};"
    "SERVER=edutracksqlsrv123.database.windows.net;"
    "DATABASE=EduTrackDB;"
    "UID=azureuser;"
    "PWD=Vyshnavi@2005;"
    "Encrypt=yes;"
    "TrustServerCertificate=no;"
    "Connection Timeout=30;"
)
# Step 2: Load data from student_performance table
df = pd.read_sql("SELECT * FROM student_performance", conn)

# Step 3: Create output directory if not exists
output_dir = "../outputs"
os.makedirs(output_dir, exist_ok=True)
# Step 4: Calculate average score column
df['avg_score'] = (df['g1'] + df['g2'] + df['g3']) / 3
# --------------------------------------------
# 📊 Plot 1: Average Score by Gender
# --------------------------------------------
gender_avg = df.groupby('sex')['avg_score'].mean()
gender_avg.plot(kind='bar', title='Average Score by Gender', color='skyblue')
plt.ylabel('Average Score')
plt.xticks(rotation=0)
plt.tight_layout()
plt.savefig(f"{output_dir}/avg_score_by_gender.png")
plt.close()

# --------------------------------------------
# 📊 Plot 2: Distribution of Final Score (G3)
# --------------------------------------------
plt.hist(df['g3'], bins=10, color='lightgreen', edgecolor='black')
plt.title("Distribution of Final Score (G3)")
plt.xlabel("Final Score")
plt.ylabel("Frequency")
plt.tight_layout()
plt.savefig(f"{output_dir}/score_distribution.png")
plt.close()
# --------------------------------------------
# 📊 Plot 3: Study Time vs Final Score (Boxplot)
# --------------------------------------------
sns.boxplot(x='studytime', y='g3', data=df, palette="Set2")
plt.title("Study Time vs Final Score (G3)")
plt.xlabel("Study Time (1=low, 4=high)")
plt.ylabel("Final Score (G3)")
plt.tight_layout()
plt.savefig(f"{output_dir}/studytime_vs_score.png")
plt.close()
# --------------------------------------------
# 📊 Plot 4: Correlation Heatmap
# --------------------------------------------
numeric_cols = df.select_dtypes(include='number')
corr = numeric_cols.corr()

plt.figure(figsize=(12, 8))
sns.heatmap(corr, annot=True, cmap='coolwarm', fmt=".2f", square=True)
plt.title("Correlation Heatmap")
plt.tight_layout()
plt.savefig(f"{output_dir}/correlation_heatmap.png")
plt.close()

print("✅ All visualizations have been saved in the outputs folder.")
